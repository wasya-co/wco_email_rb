//
// require rails-ujs
//
// require wco/application
// require ./contexts
// require ./conversations
//

console.log('loaded wco_email/application.js')
;
